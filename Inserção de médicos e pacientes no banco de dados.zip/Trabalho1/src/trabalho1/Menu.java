package trabalho1;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Menu extends JFrame{
	private JButton medico,paciente;
	
	public Menu(){
		this.setSize(584,368);
		
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 568, 329);
		getContentPane().add(panel);
		panel.setBackground(new java.awt.Color(0, 153, 204));
		panel.setLayout(null);
		

		JButton paciente = new JButton("Paciente");
		paciente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				paciente paci = new paciente();
			    paci.setVisible(true);
			    paci.setLocationRelativeTo(null);
			    dispose();
				
			}
		});
		
		paciente.setBounds(85, 108, 139, 110);
		panel.add(paciente);
		paciente.setBackground(new java.awt.Color(51, 51, 255));
        paciente.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        paciente.setForeground(new java.awt.Color(255, 255, 255));
        
        JButton Medico = new JButton("Medico");
        Medico.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		medico medic = new medico();
        		medic.setVisible(true);
        		medic.setLocationRelativeTo(null);
        		dispose();
        	}
        });
        Medico.setForeground(Color.WHITE);
        Medico.setFont(new Font("Arial", Font.BOLD, 18));
        Medico.setBackground(new Color(51, 51, 255));
        Medico.setBounds(350, 108, 139, 110);
        panel.add(Medico);
        
        JLabel lblNewLabel_1 = new JLabel("O que voc\u00EA deseja inserir no sistema?");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setForeground(Color.WHITE);
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 19));
        lblNewLabel_1.setBounds(0, 0, 568, 42);
        panel.add(lblNewLabel_1);
		
	      this.setVisible(true);
		  this.setLocationRelativeTo(null);
		  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		new Menu();
	}
}
