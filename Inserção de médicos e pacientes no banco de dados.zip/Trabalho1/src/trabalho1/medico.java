package trabalho1;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.text.MaskFormatter;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Connection;
import javax.swing.DefaultComboBoxModel;

public class medico extends JFrame {
	
	public void alimenta(){
        for(int i=20; i<=60; i++){
        	cargahoraria.addItem(Integer.toString(i));
        }
    }
	
	public static String Formata(String data){
	      String ano = data.substring(6); 
	      String dia = data.substring(0,2);
	      String mes = data.substring(3,5);
	      return (ano + "-"+ mes+"-"+dia);
	    }
	
	public boolean validadata(String data) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            sdf.parse(data);
            return true;
        } catch (ParseException ex) {
            return false;
        }
    }
	
	public static boolean Validanome(String nome){
        boolean r = false;
    for(int i = 0; i < nome.length(); i++){
            Character caractere = nome.charAt(i);    
            if(Character.isDigit(caractere)){  
                r = false;
            }else
                r = true;
    }    
    return r;     
}
	
	//verifica se o CPF � v�lido
    public static int ValidaCPF(String cpf){
    		
    	

        String cpfnaoformatado = cpf; // copia o cpf de entrada
        cpf = cpf.replaceAll("\\.",""); // remove pontos
        cpf = cpf.replaceAll("-","");  //remove tra�os
        String digitos = null;
        int v[] = new int[12];  // vetor para digito1
        int v2[] = new int[12]; // vetor para digito2
        int n1 = 0, n2 = 0;
        
        for(int i=0; i<11; i++){
            v[i] = Integer.parseInt(cpf.substring(i,i+1));
            v2[i]= Integer.parseInt(cpf.substring(i,i+1));
        }

        // digito1
        for(int i=0, j=10; i<11; i++,j--){
            v[i] = v[i]*j;
            if(j >=2){
               n1 = n1+v[i];
            }
        } 
        if(n1 % 11 < 2){
            n1=0;
        }if(n1 >= 2){
            n1 = 11 - (n1 % 11);
        }

       // digito2
        for(int i=0, j=11; i<11; i++,j--){
           v2[i] = v2[i]*j;
            if(j >=2){
               n2 = n2+v2[i];
            }
        }
        if(n2 % 11 < 2){
            n2=0;
        }if(n2 >= 2){
            n2 = 11 - (n2 % 11);
        }
        
        digitos = (n1+""+n2); // junta os 2 digitos   
        
        if(digitos.equals(cpfnaoformatado.substring(12))){// compara os 2 ultimos digitos do CPF cadastrado
            return 1; // cpf v�lido
        }else{
            return 0; // cpf inv�lido
        }
            
    }
	
	
	private JTextField nome;
	private javax.swing.JComboBox<String> cargahoraria;
	private JComboBox<String> sigla;
	private JTextField crm;
	private javax.swing.JFormattedTextField data_nascimento;
	private javax.swing.JFormattedTextField data_contrato;
	private javax.swing.JButton sair;
	private javax.swing.JPanel panel;
	
	
	public medico() {
		getContentPane().setLayout(null);
		this.setSize(584,368);
		this.setUndecorated(true);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 584, 368);
		panel.setBackground(new java.awt.Color(0, 153, 204));
		panel.setLayout(null);
		getContentPane().add(panel);
		
		JLabel lblNewLabel_1 = new JLabel("M\u00E9dico");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 19));
		lblNewLabel_1.setBounds(0, 0, 584, 31);
		panel.add(lblNewLabel_1);
		
		nome = new JTextField();
		nome.setColumns(10);
		nome.setBounds(42, 75, 170, 20);
		panel.add(nome);
		
		data_nascimento = new JFormattedTextField();
	    data_contrato = new JFormattedTextField();		
		try {
			data_nascimento= new JFormattedTextField(new
			MaskFormatter("##/##/####"));
			
			data_contrato = new JFormattedTextField(new
			MaskFormatter("##/##/####"));
			
		}catch(ParseException e) {
			e.printStackTrace();
		}
		
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(42, 42, 151, 20);
		panel.add(lblNewLabel);
		
		JLabel lblDataDeNascimento = new JLabel("Data de nascimento");
		lblDataDeNascimento.setHorizontalAlignment(SwingConstants.CENTER);
		lblDataDeNascimento.setForeground(Color.WHITE);
		lblDataDeNascimento.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblDataDeNascimento.setBounds(370, 47, 157, 20);
		panel.add(lblDataDeNascimento);
		
		
		data_nascimento.setBounds(370, 75, 157, 20);
		panel.add(data_nascimento);
		
		data_contrato.setBounds(42, 179, 170, 20);
		panel.add(data_contrato);
		
		JLabel lblcontrato = new JLabel("Data de contrato");
		lblcontrato.setHorizontalAlignment(SwingConstants.CENTER);
		lblcontrato.setForeground(Color.WHITE);
		lblcontrato.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblcontrato.setBounds(42, 140, 157, 20);
		panel.add(lblcontrato);
		
		JLabel lblCargaHorria = new JLabel("Carga Hor\u00E1ria");
		lblCargaHorria.setHorizontalAlignment(SwingConstants.CENTER);
		lblCargaHorria.setForeground(Color.WHITE);
		lblCargaHorria.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCargaHorria.setBounds(370, 145, 157, 20);
		panel.add(lblCargaHorria);
		
		cargahoraria = new JComboBox();
		cargahoraria.setBounds(370, 178, 157, 22);
		panel.add(cargahoraria);
		
		JButton inserir = new JButton("Inserir");
		inserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final String url = "jdbc:mysql://localhost:3306/hospital";
				final String user = "root";
				final String password = "";

			        //chama a fun��o para formatar a data cadastrada
			        String data_nasc = Formata(data_nascimento.getText());
			        String data_contrat= Formata(data_contrato.getText());
			        
			        //Faz a conex�o com o banco de dados
			        try {
			        Connection conexao = DriverManager.getConnection(url, user,password );
			        Statement  comando = conexao.createStatement();
			        
			        if(Validanome(nome.getText())==false){
			            JOptionPane.showMessageDialog(null, "O nome s� pode conter letras!");     
			        }
			        else if(crm.getText().length()<4 || crm.getText().length()>10){
			            JOptionPane.showMessageDialog(null, "O CRM pode ter no m�nimo 4 n�meros e no m�ximo 10 numeros.");    
			        }
			        else if(validadata(data_nascimento.getText())==false  || validadata(data_contrato.getText())==false ){
			            JOptionPane.showMessageDialog(null,"Data incorreta!");
			        }
			        else{
			            comando.executeUpdate("INSERT INTO medico(crm, nome, data_nascimento, data_contrato, carga_horaria_semanal)"
			                + " VALUES ("+"'" +crm.getText().trim()+ "/"+sigla.getSelectedItem()+ "'" +  ","
			                            +"'" + nome.getText().trim()+ "'" +  ","
			                            +"'"+ data_nasc.trim() + "'" +  ","
			                            +"'"+ data_contrat.trim() + "'" +  ","
			                            +cargahoraria.getSelectedItem()+");");
			                            System.out.println(comando);
			                            JOptionPane.showMessageDialog(null, "Inserido com sucesso!");
			                
			                //Limpa os campos ap�s inserir os dados corretamente           
			                nome.setText("");
			                crm.setText("");
			                data_nascimento.setText("");
			                data_contrato.setText("");
		            
			        }
			         
			        } catch (Exception e1) {         
			            JOptionPane.showMessageDialog(null,"Erro: " + e1.getMessage());		            
			        }
				
			}
		});
		
		inserir.setFont(new Font("Tahoma", Font.BOLD, 12));
		inserir.setForeground(new Color(0, 204, 51));
		inserir.setBounds(326, 295, 89, 23);
		panel.add(inserir);
		
	    sair = new JButton("Sair");
		sair.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
		        Menu p = new Menu();
		        p.setVisible(true);
		        p.setLocationRelativeTo(null);
		        dispose();
			}
		});
		sair.setForeground(new Color(204, 0, 51));
		sair.setFont(new Font("Tahoma", Font.BOLD, 12));
		sair.setBounds(438, 296, 89, 23);
		panel.add(sair);
		
		crm = new JTextField();
		crm.setBounds(42, 250, 117, 20);
		panel.add(crm);
		crm.setColumns(10);
		
		sigla = new JComboBox();
		sigla.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", " " }));
		sigla.setBounds(169, 249, 43, 22);
		panel.add(sigla);
		
		JLabel lblcrm = new JLabel("CRM");
		lblcrm.setHorizontalAlignment(SwingConstants.CENTER);
		lblcrm.setForeground(Color.WHITE);
		lblcrm.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblcrm.setBounds(42, 219, 157, 20);
		panel.add(lblcrm);
		alimenta();
		
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}


	public static void main(String[] args) {
		new medico();
	}
}
