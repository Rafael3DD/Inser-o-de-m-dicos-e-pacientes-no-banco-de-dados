package trabalho1;

import javax.swing.JFrame;

public class Principal {

	public static void main(String[] args) {
		Menu p = new Menu();
		p.setVisible(true);
		p.setLocationRelativeTo(null);
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
