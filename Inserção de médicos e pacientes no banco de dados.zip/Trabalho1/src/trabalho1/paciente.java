package trabalho1;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.text.MaskFormatter;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class paciente extends JFrame {
	//Formata a data para ser aceita no Mysql
    public static String Formata(String data){
      String ano = data.substring(6); 
      String dia = data.substring(0,2);
      String mes = data.substring(3,5);
      return (ano + "-"+ mes+"-"+dia);
    }
    
    //verifica se a data � v�lida
    public boolean validadata(String data) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            sdf.parse(data);
            return true;
        } catch (ParseException ex) {
            return false;
        }
    }
    
    //verifica se o CPF � v�lido
    public static int ValidaCPF(String cpf){
        String cpfnaoformatado = cpf; // copia o cpf de entrada
        cpf = cpf.replaceAll("\\.",""); // remove pontos
        cpf = cpf.replaceAll("-","");  //remove tra�os
        String digitos = null;
        int v[] = new int[12];  // vetor para digito1
        int v2[] = new int[12]; // vetor para digito2
        int n1 = 0, n2 = 0;
        
        for(int i=0; i<11; i++){
            v[i] = Integer.parseInt(cpf.substring(i,i+1));
            v2[i]= Integer.parseInt(cpf.substring(i,i+1));
        }

        // digito1
        for(int i=0, j=10; i<11; i++,j--){
            v[i] = v[i]*j;
            if(j >=2){
               n1 = n1+v[i];
            }
        } 
        if(n1 % 11 < 2){
            n1=0;
        }if(n1 >= 2){
            n1 = 11 - (n1 % 11);
        }

       // digito2
        for(int i=0, j=11; i<11; i++,j--){
           v2[i] = v2[i]*j;
            if(j >=2){
               n2 = n2+v2[i];
            }
        }
        if(n2 % 11 < 2){
            n2=0;
        }if(n2 >= 2){
            n2 = 11 - (n2 % 11);
        }
        
        digitos = (n1+""+n2); // junta os 2 digitos   
        
        if(digitos.equals(cpfnaoformatado.substring(12))){// compara os 2 ultimos digitos do CPF cadastrado
            return 1; // cpf v�lido
        }else{
            return 0; // cpf inv�lido
        }
            
    }
    //verifica se o nome possui apenas letras.
    public static boolean Validanome(String nome){
            boolean r = false;
        for(int i = 0; i < nome.length(); i++){
                Character caractere = nome.charAt(i);    
                if(Character.isDigit(caractere)){  
                    r = false;
                }else
                    r = true;
        }    
        return r;     
    }
	
	
	
	private JTextField nome;
	private JFormattedTextField data_nascimento;
	private JFormattedTextField data_registro;
	private JFormattedTextField cpf;
	
	
	public paciente() {
		getContentPane().setLayout(null);
		this.setUndecorated(true);
		this.setSize(584,368);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 584, 368);
		getContentPane().add(panel);
		panel.setBackground(new java.awt.Color(0, 153, 204));
		panel.setLayout(null);
		
		nome = new JTextField();
		nome.setBounds(39, 75, 151, 20);
		nome.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(39, 42, 151, 20);
		
	
		try {
			data_nascimento = new JFormattedTextField(new
			MaskFormatter("##/##/####"));
			data_registro = new JFormattedTextField(new
			MaskFormatter("##/##/####"));
			cpf = new JFormattedTextField(new
					MaskFormatter("###.###.###-##"));
			
		}catch(ParseException e) {
			e.printStackTrace();
		}
		
		
		JLabel lblDataDeNascimento = new JLabel("Data de nascimento");
		lblDataDeNascimento.setHorizontalAlignment(SwingConstants.CENTER);
		lblDataDeNascimento.setForeground(Color.WHITE);
		lblDataDeNascimento.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblDataDeNascimento.setBounds(373, 47, 151, 20);
		
		
		
		
		data_nascimento.setBounds(373, 75, 151, 20);
		
		
		
		JLabel lbldata_registro = new JLabel("Data de registro");
		lbldata_registro.setHorizontalAlignment(SwingConstants.CENTER);
		lbldata_registro.setForeground(Color.WHITE);
		lbldata_registro.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbldata_registro.setBounds(39, 172, 151, 20);
		
		
		
		data_registro.setBounds(39, 215, 151, 20);
		
		
		JLabel lblCPF = new JLabel("CPF");
		lblCPF.setHorizontalAlignment(SwingConstants.CENTER);
		lblCPF.setForeground(Color.WHITE);
		lblCPF.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCPF.setBounds(373, 172, 151, 20);
		
		
		
		cpf.setBounds(373, 215, 151, 20);
		
		
		JLabel lblNewLabel_1 = new JLabel("Paciente");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 19));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(0, 0, 584, 31);
		panel.add(lblNewLabel_1);
		panel.add(lblCPF);
		panel.add(lbldata_registro);
		panel.add(lblDataDeNascimento);
		panel.add(lblNewLabel);
		
		
		panel.add(cpf);
		panel.add(data_registro);
		panel.add(data_nascimento);
		panel.add(nome);
		
		JButton inserir = new JButton("Inserir");
		inserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final String url = "jdbc:mysql://localhost:3306/hospital";
				final String user = "root";
				final String password = "";
			        
			        //chama a fun��o para formatar a data cadastrada
			        String data_nasc = Formata(data_nascimento.getText());
			        String data_reg= Formata(data_registro.getText());
			        
			        //Faz a conex�o com o banco de dados
			        try {
			            if(Validanome(nome.getText())==false){
			            JOptionPane.showMessageDialog(null, "O nome s� pode conter letras!");     
			        }    
			            else if(ValidaCPF(cpf.getText()) == 0){
			            JOptionPane.showMessageDialog(null,"CPF Inv�lido!");
			        }
			            else if(validadata(data_nascimento.getText())==false  || validadata(data_registro.getText())==false ){
			            JOptionPane.showMessageDialog(null,"Data incorreta!");
			        }
			            else{
			            Connection conexao = DriverManager.getConnection(url, user,password );
			            Statement  comando = conexao.createStatement();
			            comando.executeUpdate("INSERT INTO paciente(cpf, nome, data_nascimento, data_registro)"
			                    + " VALUES ("+"'" +cpf.getText()+ "'" +  ","
			                        +"'" + nome.getText()+ "'" +  ","
			                        +"'"+ data_nasc + "'" +  ","
			                        +"'"+ data_reg + "'" +");");
			                        System.out.println(comando);
			                        JOptionPane.showMessageDialog(null, "Inserido com sucesso!");
			                
			                //Limpa os campos ap�s inserir os dados corretamente                 
			                nome.setText("");
			                cpf.setText("");
			                data_nascimento.setText("");
			                data_registro.setText("");
			                
			        }         
			        } catch (Exception e1) {
			            JOptionPane.showMessageDialog(null,"Erro: " + e1.getMessage());	
			        }
				
				
			}
		});
		inserir.setForeground(new Color(0, 204, 51));
		inserir.setFont(new Font("Tahoma", Font.BOLD, 12));
		inserir.setBounds(323, 294, 89, 23);
		panel.add(inserir);
		
		JButton sair = new JButton("Sair");
		sair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        Menu p = new Menu();
		        p.setVisible(true);
		        p.setLocationRelativeTo(null);
		        dispose();
			}
		});
		sair.setForeground(new Color(204, 0, 51));
		sair.setFont(new Font("Tahoma", Font.BOLD, 12));
		sair.setBounds(435, 295, 89, 23);
		panel.add(sair);
		
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		
		new paciente();
	}
}
